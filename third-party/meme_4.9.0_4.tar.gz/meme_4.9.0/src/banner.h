/*
 * $Id: banner.h 1048 2006-07-06 20:07:44Z cegrant $
 * 
 */


#ifndef BANNER_H
#define BANNER_H

extern void banner(
  char *program, /* name of program */
  FILE *outfile  /* destination for output */
); 


#endif
